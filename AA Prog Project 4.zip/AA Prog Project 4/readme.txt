Andres Acuna
12/4/2021
Linux
Looks like the program runs without any warning or major problem.
Not sure about the code part that had a bug, you said in class.

The count was important, beign the total number of nodes in the binary search tree.
I used recursion many times in the project.
I was careful with the left and right part of the minimum and maximum values.
